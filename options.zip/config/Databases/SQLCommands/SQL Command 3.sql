SELECT
       UNIX_TIMESTAMP(invoice_rma_created_ts),
       SUM(t.e_qty),
       SUM(t.e_price),
       SUM(t.r_qty),
       SUM(t.r_price)
  FROM invoice_rma
  JOIN (SELECT SUM(IF(invoice_rma_connect_type = "exchange", invoice_rma_connect_qty, 0)) AS e_qty,
       SUM(IF(invoice_rma_connect_type = "exchange", pc_price, 0)) AS e_price,
       SUM(IF(invoice_rma_connect_type = "return", invoice_rma_connect_qty, 0)) AS r_qty,
       SUM(IF(invoice_rma_connect_type = "return", pc_price, 0)) AS r_price,
       invoice_rma_connect_rma_id
FROM invoice_rma_connect JOIN product_child ON pc_id = invoice_rma_connect_pc_id GROUP BY invoice_rma_connect_rma_id) AS t
ON invoice_rma_id = t.invoice_rma_connect_rma_id WHERE invoice_rma_status != "denied" AND DATE_FORMAT(invoice_rma_created_ts,'%m-%d-%Y') BETWEEN '02-01-2012' AND '10-31-2012 23:59:59' GROUP BY week(invoice_rma_created_ts) ORDER BY invoice_rma_created_ts