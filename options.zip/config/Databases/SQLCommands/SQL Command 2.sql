select IF(
    inventory_option_detail_id IS NULL,
    rma_option_main_id,
    CONCAT(rma_option_main_id, '-',inventory_option_detail_id)),
    m.*,
    s.*
FROM rma_options_main m
LEFT JOIN rma_options_sub s ON rma_option_main_id = inventory_option_detail_option_id
ORDER BY rma_option_main_value,
inventory_option_detail_details
